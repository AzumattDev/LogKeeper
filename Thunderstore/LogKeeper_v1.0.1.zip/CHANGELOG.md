| `Version` | `Update Notes`                                                |
|-----------|---------------------------------------------------------------|
| 1.0.1     | - Version bump to make you happy that it works with Ashlands. |
| 1.0.0     | - Initial Release                                             |